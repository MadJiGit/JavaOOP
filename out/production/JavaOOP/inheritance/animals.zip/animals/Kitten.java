package inheritance.animals;

public class Kitten extends Cat {

    final static String SOUND = "Meow";
    final static String GENDER = "Female";

    public Kitten(String name, String gender, int age) {
        super(name, gender, age);
        super.setGender(GENDER);
        setSound(SOUND);
    }
}
