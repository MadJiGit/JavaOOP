package inheritance.animals;

public class Animal {

    final static String SOUND = "";
    private String name;
    private String gender;
    private String sound = "";
    private int age;

    public Animal(String name, String gender, int age){
        this.setName(name);
        this.setGender(gender);
        this.setAge(age);
        this.setSound(SOUND);
    }

    @Override
    public String toString() {
        return String.format("%s%n%s %d %s%n%s ", this.getClass().getSimpleName(), this.getName(), this.getAge(), this.getGender(), this.produceSound());
    }

    protected void setSound(String sound){
        this.sound = sound;
    }

    public String produceSound(){
        return this.sound;
    }

    public String getName() {
        return name;
    }

    protected void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    protected void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    protected void setAge(int age) {
        this.age = age;
    }
}
