package inheritance.animals;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        String animalType = scanner.nextLine();
        ArrayList<Animal> animals = new ArrayList<>();

        while (true) {
            if (animalType.isBlank() || animalType.isEmpty()) {
                System.out.println("Invalid input!");
            } else if (animalType.equals("Beast!")) {

                for (Animal animal : animals) {
                    System.out.println(animal.toString());
                }
                break;
            } else {

                String[] animalData = scanner.nextLine().split("\\s+");
                String animalName = animalData[0];
                int animalAge = Integer.parseInt(animalData[1]);
                String animalGender = animalData[2];

                if (animalName.isEmpty() || animalName.isBlank()
                        || animalAge < 0
                        || animalGender.isEmpty() || animalGender.isBlank()) {
                    System.out.println("Invalid input!");
                } else {

                    switch (animalType) {
                        case "Dog":
                            Dog dog = new Dog(animalName, animalGender, animalAge);
                            animals.add(dog);
                            break;
                        case "Cat":
                            Cat cat = new Cat(animalName, animalGender, animalAge);
                            animals.add(cat);
                            break;
                        case "Frog":
                            Frog frog = new Frog(animalName, animalGender, animalAge);
                            animals.add(frog);
                            break;
                        case "Kittens":
                            Kitten kitten = new Kitten(animalName, animalGender, animalAge);
                            animals.add(kitten);
                            break;
                        case "Tomcat":
                            Tomcat tomcat = new Tomcat(animalName, animalGender, animalAge);
                            animals.add(tomcat);
                            break;
                        default:
                            System.out.println("Invalid input!");
                    }
                }
            }

            animalType = scanner.nextLine();
        }
    }
}
