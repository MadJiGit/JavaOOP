package inheritance.animals;

public class Tomcat extends Cat {

    final static String SOUND = "MEOW";
    final static String GENDER = "Male";

    public Tomcat(String name, String gender, int age) {
        super(name, gender, age);
        super.setGender(GENDER);
        setSound(SOUND);
    }
}
