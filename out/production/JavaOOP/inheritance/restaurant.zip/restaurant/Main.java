package inheritance.restaurant;

public class Main {
    public static void main(String[] args) {

    }
}
