package inheritance.restaurant;

import java.math.BigDecimal;

public class Coffee extends HotBeverage {

    final static double COFFEE_MILLILITERS = 50;
    final static BigDecimal COFFEE_PRICE = BigDecimal.valueOf(3.50);
    double caffeine;

    public Coffee(String name, BigDecimal price, double milliliters) {
        super(name, price, milliliters);
        super.setPrice(COFFEE_PRICE);
        super.setMilliliters(COFFEE_MILLILITERS);
    }

    public double getCaffeine(){
        return this.caffeine;
    }
}
