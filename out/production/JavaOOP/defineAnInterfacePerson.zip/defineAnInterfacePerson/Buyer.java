package defineAnInterfacePerson;

public interface Buyer {
    void buyFood();
    int getFood();
}
