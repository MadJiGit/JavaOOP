package defineAnInterfacePerson;

public interface Identifiable {
    String getId();
}
