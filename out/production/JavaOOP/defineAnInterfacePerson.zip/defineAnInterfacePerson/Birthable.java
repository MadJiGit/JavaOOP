package defineAnInterfacePerson;

public interface Birthable {
    String getBirthDate();
}
