package ferrari;

public interface Car {

    String brakes();
    String gas();
    String getName();
    String getModel();
}
