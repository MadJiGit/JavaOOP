import abstraction.studentSystem.Student;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        // Student System task

        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split("\\s+");

        ArrayList<Student> students = new ArrayList<>();

        while(!input[0].equals("Exit")) {

            String task = input[0];
            String name = input[1];

            if(task.equals("Create")) {
                int age = Integer.parseInt(input[2]);
                double grade = Double.parseDouble(input[3]);
                Student student = new Student(name, age, grade);
                students.add(student);
            } else if (task.equals("Show")) {

                for(Student st : students) {
                    if(st.getStudentName().equals(name)) {
                        System.out.println(st.toString());
                    }
                }
            }

            input = scanner.nextLine().split("\\s+");
        }



        /*
        // Rhombus task
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split("\\s+");
        RhombusOfStars rhombus = new RhombusOfStars(Integer.parseInt(input[0]));
        rhombus.calculateRhombus();
        System.out.println(rhombus);
        */

        // Point In Rectangle task
        /*
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split("\\s+");
        int[] pointInputs = Arrays
                .stream(input)
                .mapToInt(Integer::parseInt)
                .toArray();

        Point X = new Point(pointInputs[0], pointInputs[1]);
        Point Y = new Point(pointInputs[2], pointInputs[3]);

        Rectangle rect = new Rectangle(X, Y);

        int iter = Integer.parseInt(scanner.nextLine());

        while(iter-- > 0) {
            input = scanner.nextLine().split("\\s+");
            int[] searchedPoint = Arrays
                    .stream(input)
                    .mapToInt(Integer::parseInt)
                    .toArray();

            Point temp = new Point(searchedPoint[0], searchedPoint[1]);

            boolean isInside = rect.isInside(temp);

//            System.out.println("For point with x = "
//                    + temp.getX()
//                    + " and y = "
//                    + temp.getY());
            System.out.println(isInside ? "true" : "false");
        }

        */

    }
}
