package carShopExtend;

public interface Sellable {
    Double getPrice();
}
