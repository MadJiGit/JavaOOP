package hero;

public class BladeKnight extends Knight{

    public BladeKnight(String username, int level) {
        super(username, level);
    }
}
