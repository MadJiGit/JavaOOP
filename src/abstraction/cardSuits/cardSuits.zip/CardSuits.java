package abstraction.cardSuits;

public enum CardSuits {

    CLUBS(0),
    DIAMONDS(1),
    HEARTS(2),
    SPADES(3);

    private final int cardValue;

    CardSuits(int type) {
        this.cardValue = type;
    }

    public int getCardValue() {
        return this.cardValue;
    }

}
