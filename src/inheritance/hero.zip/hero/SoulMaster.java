package inheritance.hero;

public class SoulMaster extends Wizard {
    public SoulMaster(String username, int level) {
        super(username, level);
    }
}
