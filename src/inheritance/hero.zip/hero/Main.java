package inheritance.hero;

public class Main {
    public static void main(String[] args) {

        Hero hero = new Hero("Hero", 111);


        System.out.println(hero.toString());
    }
}
